package fiap.com.jogo;

public class Fase {
	
	public void carregar(Jogador jogador) {
        System.out.println("Elemento visual carregado: " + jogador.getClass().getSimpleName());
    }

}

package fiap.com.jogo;

public class Mago extends Jogador {
	
	private int magia;
	
	// Construtor
    public Mago(String nome, int magia) {
        super(nome, "Mago");
        this.magia = magia;
    }
	
    public int getMagia() {
        return magia;
    }

    public void setMagia(int magia) {
        this.magia = magia;
    }
	
    public void mover(int x, int y) {
        System.out.println("O mago " + getNome() + " está se movendo com magia para a posição (" + x + ", " + y + ").");
    }
    
}

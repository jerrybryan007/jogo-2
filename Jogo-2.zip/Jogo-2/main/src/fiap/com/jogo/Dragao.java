package fiap.com.jogo;

public class Dragao {
	
	 private int poder;
	
	 public Dragao(int posX, int posY, int poder) {
	        super();
	        this.poder = poder;
	    }
	    
	    public void mover(int x, int y) {
	    }
	    
	    public int getPoder() {
	        return poder;
	    }
	    
	    public void setPoder(int poder) {
	        this.poder = poder;
	    }

}

package fiap.com.jogo;

public class Guerreiro extends Jogador {
	
	private int forca;
	
	// Construtor
    public Guerreiro(String nome, int forca) {
        super(nome, "Guerreiro");
        this.forca = forca;
    }
	
    public int getForca() {
        return forca;
    }

    public void setForca(int forca) {
        this.forca = forca;
    }
    
    public void mover(int x, int y) {
        System.out.println("O guerreiro " + getNome() + " está se movendo com força para a posição (" + x + ", " + y + ").");
    }

}

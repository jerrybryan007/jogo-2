package fiap.com.jogo;

public class BolaDeFogo {

private int poder;
    
    public BolaDeFogo(int posX, int posY, int poder) {
        super();
        this.poder = poder;
    }
    
    public void mover(int x, int y) {
        this.poder = x + 10;
        this.poder = y + 10;
    }
    
    public int getPoder() {
        return poder;
    }
    
    public void setPoder(int poder) {
        this.poder = poder;
    }
	
}

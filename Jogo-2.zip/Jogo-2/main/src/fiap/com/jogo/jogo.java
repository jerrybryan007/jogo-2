package fiap.com.jogo;

public class jogo {

	public static void main(String[] args) {
		Jogador jogador1 = new Jogador("Joao");
		Jogador jogador2 = new Jogador();
		
		System.out.println("Jogador1 " + jogador1.getNome()+ 
									"XP=" + jogador1.getXp() +
									" HP=" + jogador1.getHp() +   
									" Envenenado=" + jogador1.isEnvenenado()   
									);
		jogador1.ganharExperiencia(5);
		jogador2.ganharExperiencia(100);
		jogador1.receberAntidoto();
		jogador2.atacar(jogador1);
		
		
		System.out.println("Jogador1 " + jogador1.getNome()+ 
				"XP=" + jogador1.getXp() +
				" HP=" + jogador1.getHp() +   
				" Envenenado=" + jogador1.isEnvenenado()   
				);
		
		System.out.println("Jogador2 XP" + jogador2.getXp());
		
		
	}
	
}
